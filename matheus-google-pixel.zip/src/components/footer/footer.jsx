import style from "../footer/footer.module.css";

const Footer = () =>{
    return(
        <footer className={style.Footer}>
            <div className={style.footerWrapper}>
                <div classeName="footer-items">
                    <ul classeName="lista">
                        <li></li>
                    </ul>
                </div>
            </div>
        </footer>
    )
}